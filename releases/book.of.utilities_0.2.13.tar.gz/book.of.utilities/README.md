---
title: README
---

# ![book](book_small.png) Book of Utilities

**book.of.utilities** seeks to facilitate execution of those repetitive, ad-hoc tasks often encountered during data processing.

## Installation

Use `remotes::install_github("delriaan/book.of.utilities", subdir = "pkg")` to install the latest version from GitHub.

## Functions

The following functional families are covered in `book.of.utilities`:

**\[Chapter 1 - Authentication\]**

<details open="true">

-   `gen_pass()`, `keyring_export()`, `keyring_import()`

</details>

**\[Chapter 2 - Calculators\]**

<details open="true">

-   `calc.geo_mean()`, `calc.harmonic_mean()`, `calc.means()`
-   `calc.rms()`, `calc.zero_mean()`, `odds2probs()`
-   `radix()`, `range_diff()`, `ranking.algorithm()`

</details>

**\[Chapter 3 - Counters\]**

<details open="true">

-   `count.cycles()`, `factor.int()`

</details>

**\[Chapter 4 - Custom Operators\]**

<details open="true">

-   `%?%`, `%??%()`, `%><%()`
-   `%bin%()`, `%if_na_empty%()`, `%tf%()`

</details>

**\[Chapter 5 - Miscellaneous\]**

<details open="true">

-   `call.recursion()`, `checksum()`, `gen.primes()`
-   `log_note()`, `polyname2orig()`, `vlogical()`

</details>

**\[Chapter 6 - Object Management\]**

<details open="true">

-   `distinct.list()`, `enlist()`, `get.object_sizes()`

</details>
